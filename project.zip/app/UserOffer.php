<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserOffer extends Model
{
    //
}
