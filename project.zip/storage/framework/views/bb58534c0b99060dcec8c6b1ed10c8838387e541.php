
<?php $__env->startSection('title','مدیریت کاربران'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(count($users)): ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>نام</th>
                    <th>موبایل</th>
                    <th>ایمیل</th>
                    <th>پیشنهاد باقیمانده</th>
                    <th>نقش</th>
                    <th>امکانات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->fullname); ?></td>
                        <td><?php echo e($item->cellphone); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->offer); ?></td>
                        <td><?php echo e($item->role_title); ?></td>
                        <td><a href="<?php echo e(Route('A_Dusers',['id' => $item->id])); ?>"<i class="glyphicon glyphicon-trash" title="حذف کاربر"></i></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($users->links()); ?>

    <?php else: ?>
        <div class="alert alert-warning">هیچ کاربری در سیستم ثبت نشده است</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/admin/users.blade.php ENDPATH**/ ?>