<?php $__env->startSection('title','سامانه مزایده'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->yieldContent('slider'); ?>

    <?php if(count($new_products)): ?>

        <div class="col-md-12">
            <h4 class="alert alert-info">جدید ترین ها : </h4>
            <?php $__currentLoopData = $new_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(Route('user.product',['slug' => $item->slug])); ?>">
                    <div class="col-md-4">
                        <img src="<?php echo e(asset($item->image)); ?>" height="200px" width="100%" alt="<?php echo e($item->title); ?>">
                        <hr>
                        <b class="text-info"><?php echo e($item->title); ?></b>
                        <hr>
                        <small>
                            <?php
                                $len = strlen($item->body);
                                if($len > 30){
                                    echo mb_substr($item->body, 0, 29, mb_detect_encoding($item->body)) . "...";
                                } else {
                                    echo $item->body;
                                }
                            ?>
                        </small>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    <?php else: ?>
        <div class="alert alert-warning">هیچ آگهی قابل پیشنهادی وجود ندارد</div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/index.blade.php ENDPATH**/ ?>