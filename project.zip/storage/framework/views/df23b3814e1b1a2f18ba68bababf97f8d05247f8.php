<?php $__env->startSection('title','مدیریت آگهی ها'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(count($products)): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>عنوان</th>
                    <th>قیمت</th>
                    <th>وضعیت</th>
                    <th>شروع مزایده</th>
                    <th>پایان مزایده</th>
                    <th>مدت پرداخت</th>
                    <th>امکانات</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td><?php echo e(number_format($item->price)); ?></td>
                        <td><?= ($item->status) ? '<span class="text-success">فروخته شد</span>' : '<span class="text-warning">ایجاد شده</span>' ?></td>
                        <td style="direction: ltr"><?php echo e($item->from_date); ?></td>
                        <td style="direction: ltr"><?php echo e($item->to_date); ?></td>
                        <td><?php echo e($item->pay_date); ?> دقیقه</td>
                        <td>
                            <i class="glyphicon glyphicon-info-sign" title=""></i>
                            <a href="<?php echo e(Route('admin.delete.product',['id' => $item->id])); ?>"><i class="glyphicon glyphicon-trash" title="حذف کالا"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($products->links()); ?>

    <?php else: ?>
        <div class="alert alert-warning">هیچ آگهی در سیستم ثبت نشده است</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/admin/products.blade.php ENDPATH**/ ?>