<?php $__env->startSection('title',"$product->title"); ?>
<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>
        
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content" dir="rtl">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">ثبت پیشنهاد</h4>
                </div>
                <div class="modal-body">

                    <?php if($result_check[0]['from_date'] && $result_check[0]['to_date'] && Auth::user()->offer > 0): ?>
                        <form action="<?php echo e(Route('user.create.offer')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="number" min="<?php echo e($product->price); ?>" name="price" class="form-control" placeholder="حداقل مبلغ پیشنهادی <?php echo e(number_format($product->price)); ?> ریال" required>
                            </div>
                            <div class="form-group">
                                <input type="hidden" name="pro_id" value="<?php echo e($product->id); ?>">
                                <button class="btn btn-info">ثبت پیشنهاد</button>
                            </div>
                        </form>
                    <?php elseif($result_check[0]['from_date'] === false): ?>
                        <div class="alert alert-warning">زمان شروع مزایده آغاز نشده است</div>
                    <?php elseif($result_check[0]['to_date'] === false): ?>
                        <div class="alert alert-warning">مهلت پیشنهاد به این آگهی تمام شده است</div>
                    <?php elseif(Auth::user()->offer == 0): ?>
                        <div class="alert alert-warning">تعداد پیشنهاد های شما تمام شده است</div>
                    <?php endif; ?>

                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">بستن</button>
                </div>
            </div>

            </div>
        </div>
        
    <?php endif; ?>
    <div class="col-md-3">
        <img src="<?php echo e(asset($product->image)); ?>" width="100%" height="300px"><hr>
        <?php if(Auth::check()): ?>
            <button type="button" <?= (Auth::id() == $product->created_id) ? 'disabled' : '' ?> class="btn btn-info col-md-12" data-toggle="modal" data-target="#myModal">ثبت پیشنهاد</button>
        <?php else: ?>
            <div class="alert alert-danger">برای پیشنهاد دادن وارد سیستم شوید</div>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <h3><?php echo e($product->title); ?></h3><hr>
        <p style="text-align: justify"><?php echo e($product->body); ?></p><hr>
        <span class="btn btn-success">قیمت : <?php echo e(number_format($product->price)); ?> ریال</span>
        <b class="btn btn-sm btn-info">تاریخ و ساعت شروع : <span dir="ltr"><?php echo e($product->from_date); ?></span></b>&nbsp;
        <b class="btn btn-sm btn-info">تاریخ و ساعت پایان : <span dir="ltr"><?php echo e($product->to_date); ?></span></b>&nbsp;
        <b class="btn btn-sm btn-danger">مهلت پرداخت : <?php echo e($product->pay_date); ?> دقیقه</b>

    </div>
    <div class="col-md-3" style="background-color: gainsboro">
        <h4>ویژگی ها</h4>
        <?php $__currentLoopData = $attrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <b><?php echo e($item->key); ?></b> : <b><?php echo e($item->value); ?></b>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-12">
        <h4>پیشنهادات</h4>
        <?php if(count($offers)): ?>
            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4" style="padding:20px;<?= ($item->status == 1) ? 'background-color:gray' : '' ?>">
                    <div class="col-md-4"><img src="<?php echo e(asset('profile.png')); ?>" width="100%" height="100px"></div>
                    <div class="col-md-8" style="<?= ($item->status == 3) ? 'background-color: lightblue' : '' ?>">
                        <b>کاربر : <?php echo e($item->offer_fullname); ?></b><hr>
                        <b>قیمت پیشنهادی : <?php echo e(number_format($item->price)); ?> ریال</b>
                        <?php if(Auth::id() == $product->created_id): ?>
                            <?php if($result_check[0]['to_date'] === false && $product->status == 0): ?>
                                <b><a href="<?php echo e(Route('user.update.offer',['slug' => $product->slug,'offer_id' => $item->id])); ?>" class="btn btn-info">انتخاب پیشنهاد</a></b>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-warning">هیچ پیشنهادی برای آگهی ثبت نشده است</div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/product.blade.php ENDPATH**/ ?>