<?php $__env->startSection('title','ثبت نام'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <h4 class="alert alert-info">ثبت نام</h4>
        <form action="<?php echo e(Route('U_Cuser')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input class="form-control" required name="fullname" placeholder="نام و نام خانوادگی" value="<?php echo e(old('fullname')); ?>">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" required name="email" placeholder="پست الکترونیک " value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <input class="form-control" required name="cellphone" placeholder="شماره همراه" value="<?php echo e(old('cellphone')); ?>">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" required name="password" placeholder="کلمه عبور">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" required name="same_password" placeholder="تکرار کلمه عبور">
            </div>
            <div class="form-group">
                <button class="btn btn-success">ثبت نام</button>
            </div>

        </form>
    </div>
    <div class="col-md-4"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/register.blade.php ENDPATH**/ ?>