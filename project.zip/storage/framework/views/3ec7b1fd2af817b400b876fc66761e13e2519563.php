
<?php $__env->startSection('title','ثبت کاربر جدید'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <form action="<?php echo e(Route('A_Cuser')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input class="form-control" required name="fullname" placeholder="نام و نام خانوادگی" value="<?php echo e(old('fullname')); ?>">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" required name="email" placeholder="پست الکترونیک " value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <input class="form-control" required name="cellphone" placeholder="شماره همراه" value="<?php echo e(old('cellphone')); ?>">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" required name="password" placeholder="کلمه عبور">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" required name="same_password" placeholder="تکرار کلمه عبور">
            </div>
            <div class="form-group">
                <select name="role_id" class="form-control" required>
                    <option selected disabled>انتخاب کنید</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <button class="btn btn-success">ثبت کاربر</button>
            </div>
        </form>
    </div>
    <div class="col-md-4"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/admin/create_user.blade.php ENDPATH**/ ?>