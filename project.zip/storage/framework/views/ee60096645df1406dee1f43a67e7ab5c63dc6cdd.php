<?php $__env->startSection('title','پیشنهاد های من'); ?>
<?php $__env->startSection('content'); ?>
    <h4>پیشنهاد های من : <?php echo e(count($offers)); ?> مورد</h4>
    <?php if(count($offers)): ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>عنوان</th>
                    <th>قیمت پایه</th>
                    <th>پیشنهاد شما</th>
                    <th>وضعیت</th>
                    <th>مهلت پرداخت</th>
                    <th>ابزار</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(Route('user.product',['slug' => $item->pro_slug])); ?>"><?php echo e($item->pro_title); ?></a></td>
                        <td><?php echo e(number_format($item->pro_price)); ?> ریال</td>
                        <td><?php echo e(number_format($item->price)); ?> ریال</td>
                        <td>
                            <?php if($item->status == 0): ?>
                                <b class="text-warning">پیشنهاد شده</b>
                            <?php elseif($item->status == 1): ?>
                                <b class="text-success">پذیرفته شده</b>
                            <?php elseif($item->status == 2): ?>
                                <b class="text-success">پرداخت شده</b>
                            <?php elseif($item->status == 3): ?>
                                <b class="text-success">ارسال شده</b>
                            <?php else: ?>
                                <b class="text-info">لغو شده</b>
                            <?php endif; ?>
                        </td>
                        <td dir="ltr" style="text-align: right"><?php echo e($item->pay_date); ?></td>
                        <td>
                            <?php if($item->pay_date > Verta::now() && $item->status != 3): ?>
                                <a href="<?php echo e(Route('user.form.order',['offer_id' => $item->id])); ?>" class="btn btn-success btn-sm">پرداخت</a>
                            <?php elseif(Verta::now() > $item->pay_date && $item->status != 3): ?>
                                <span class="btn btn-danger btn">عدم پرداخت</span>
                            <?php else: ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-warning">هیچ پیشنهادی توسط شما ثبت نشده است</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/my_offers.blade.php ENDPATH**/ ?>