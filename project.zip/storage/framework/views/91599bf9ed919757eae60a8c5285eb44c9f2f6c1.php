<?php $__env->startSection('title','ثبت اطلاعات سفارش'); ?>
<?php $__env->startSection('content'); ?>
    <h4>ثبت سفارش</h4>
    <table class="table table-hover text-center">
        <tr>
            <td><?php echo e($product->title); ?></td>
            <td>قیمت پایه : <?php echo e(number_format($product->price)); ?> ریال</td>
            <td>مهلت پرداخت : <span dir="ltr"><?php echo e($offer->pay_date); ?></span></td>
            <td>پیشنهاد شما : <?php echo e(number_format($offer->price)); ?> ریال</td>
        </tr>
    </table>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <?php if($offer->pay_date > Verta::now()): ?>
            <h4 class="alert alert-info">اطلاعات تکمیلی سفارش</h4>
            <form action="<?php echo e(Route('user.create.order')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="number" class="form-control" required value="<?php echo e(old('cellphone')); ?>" name="cellphone" placeholder="شماره همراه">
                </div>
                <div class="form-group">
                    <textarea name="address" class="form-control" required placeholder="آدرس دریافت سفارش"><?php echo e(old('address')); ?></textarea>
                </div>
                <div class="form-group">
                    <textarea name="description" class="form-control" placeholder="توضیحات بیشتری بدهید"><?php echo e(old('description')); ?></textarea>
                </div>
                <div class="form-group">
                    <input hidden name="price" value="<?php echo e($offer->price); ?>">
                    <input hidden name="pro_id" value="<?php echo e($offer->pro_id); ?>">
                    <input hidden name="offer_id" value="<?php echo e($offer->id); ?>">
                    <button class="btn btn-success">ثبت اطلاعات سفارش و پرداخت</button>
                </div>
            </form>
        <?php else: ?>
            <div class="alert alert-warning">مهلت پرداخت هزینه ی پیشنهاد تمام شده است</div>
        <?php endif; ?>
    </div>
    <div class="col-md-4"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/create_order.blade.php ENDPATH**/ ?>