<?php $__env->startSection('title','پیشخوان'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <h4 class="alert alert-info">خوش آمدید : <?php echo e(Auth::user()->fullname); ?></h4>
    </div>
    <div class="col-md-2"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>