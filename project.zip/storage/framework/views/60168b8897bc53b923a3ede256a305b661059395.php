<?php $__env->startSection('title','ورود به سیستم'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-4"></div>
    <div class="col-md-4">
        <form action="<?php echo e(Route('user.login')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <h3 class="alert alert-success">ورود به سیستم</h3>
            <div class="form-group">
                <input type="text" class="form-control" name="mobile" required placeholder="شماره همراه">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" required placeholder="کلمه عبور">
            </div>
            <div class="form-group">
                <button class="btn btn-success">ورود به سیستم</button>
            </div>
        </form>
    </div>
    <div class="col-md-4"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/login.blade.php ENDPATH**/ ?>