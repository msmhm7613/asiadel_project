<?php $__env->startSection('title','نقش ها'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(count($roles)): ?>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>#</td>
                    <th>عنوان</td>
                    <th>سطح دسترسی</td>
                    <th>امکانات</td>
                </tr>
            </thead>
            <body>
                <?php $i = 1 ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($item->title); ?></td>
                        <td>
                            <?php $__currentLoopData = $item->access; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $access): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <small><span type="button" class="btn btn-sm btn-warning"><?php echo e($access->access_title); ?></span></small>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                        <td></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </body>
        </table>
        <hr>
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <form action="<?php echo e(Route('admin.create.role')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <h3>تعریف نقش</h3>
                <div class="form-group">
                    <input class="form-control" name="title" required placeholder="عنوان نقش را وارد کنید">
                </div>
                <h4>دسترسی ها را انتخاب کنید</h4>
                <div class="form-group">
                    <input name="access[]" type="checkbox" value="1">&nbsp;مدیریت آگهی ها
                    <br><input name="access[]" type="checkbox" value="2">&nbsp;ثبت آگهی جدید
                    <br><input name="access[]" type="checkbox" value="3">&nbsp;مدیریت کوپن ها
                    <br><input name="access[]" type="checkbox" value="4">&nbsp;ثبت کوپن جدید
                    <br><input name="access[]" type="checkbox" value="5">&nbsp;مدیریت کاربران
                    <br><input name="access[]" type="checkbox" value="6">&nbsp;ثبت کاربر جدید
                </div>
                <div class="form-group">
                    <button class="btn btn-sm btn-success">ثبت نقش</button>
                </div>
            </form>
        </div>
        <div class="col-md-2"></div>
    <?php else: ?>
        <div class="alert alert-warning">هیچ نقشی در سیستم ثبت نشده است</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/admin/roles.blade.php ENDPATH**/ ?>