<?php $__env->startSection('title','آگهی های من'); ?>
<?php $__env->startSection('content'); ?>
    <h4>آگهی های من</h4>

    <?php if(count($products)): ?>
        <table class="table table-stripped">
            <thead>
            <tr>
                <th>عنوان</th>
                <th>تصویر</th>
                <th>قیمت</th>
                <th>وضعیت</th>
                <th>زمان آغاز</th>
                <th>زمان پایان</th>
                <th>مهلت پرداخت</th>
                <th>پیشنهادها</th>
                <th>امکانات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->title); ?></td>
                    <td><img src="<?php echo e(asset($item->image)); ?>" width="50px" height="50px"></td>
                    <td><?php echo e(number_format($item->price)); ?> ریال</td>
                    <td>
                        <?php switch($item->status):
                            case (0): ?>
                                <span class="btn btn-sm btn-info">ایجاد شده</span>
                                <?php break; ?>
                            <?php case (1): ?>
                                <span class="btn btn-sm btn-warning">انتخاب شده</span>
                                <?php break; ?>
                            <?php case (2): ?>
                                <button class="btn btn-sm btn-success" type="button" data-toggle="modal"
                                        data-target="#modal_<?php echo e($item->id); ?>">آماده ارسال
                                </button>
                                <?php break; ?>
                            <?php case (3): ?>
                                <span class="btn btn-sm btn-success">ارسال شده</span>
                                <?php break; ?>
                            <?php default: ?>

                        <?php endswitch; ?>
                    </td>
                    <td dir="ltr"><?php echo e($item->from_date); ?></td>
                    <td dir="ltr"><?php echo e($item->to_date); ?></td>
                    <td><?php echo e($item->pay_date); ?> دقیقه</td>
                    <td><?php echo e(count($item->offers)); ?></td>
                    <td><a href="<?php echo e(Route('user.product',['slug' => $item->slug])); ?>"><i
                                class="glyphicon glyphicon-info-sign" title="بررسی پیشنهاد ها"></i></a></td>
                </tr>
                <?php if($item->order_info): ?>
                
                <div id="modal_<?php echo e($item->id); ?>" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">ارسال سفارش</h4>
                            </div>
                            <div class="modal-body text-center" dir="rtl">
                                <h4 class="alert alert-info">اطلاعات سفارش</h4>
                                <b>خریدار : <?php echo e($item->buyer_info['fullname']); ?></b><hr>
                                <b>همراه : <?php echo e($item->order_info['cellphone']); ?></b><hr>
                                <b>آدرس : <?php echo e($item->order_info['address']); ?></b><hr>
                                <b>مبلغ پرداختی : <?php echo e(number_format($item->order_info['price'])); ?> ریال</b><hr>
                                <a href="<?php echo e(Route('user.create.order.get',['order_id' => $item->order_id])); ?>" class="btn btn-info">ارسال سفارش</a>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">بستن</button>
                            </div>
                        </div>

                    </div>
                </div>
                
                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-warning">هیچ آگهی توسط شما ثبت نشده است ، اولین آگهی خود را ثبت کنید</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Hadi\Desktop\project\resources\views/my_products.blade.php ENDPATH**/ ?>